const crypto = require('crypto');
const { sb, amplo } = require('./_lib');
const MIN = 5, MAX = 10000;
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' });
  const need = ['AMPLOPAY_PUBLIC_KEY', 'AMPLOPAY_SECRET_KEY', 'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'];
  if (process.env.PAYMENTS_ENABLED !== 'true' || need.some(k => !process.env[k]) || process.env.CAMPAIGN_OPEN === 'false')
    return res.status(503).json({ error: 'unavailable', message: 'Os pagamentos estão temporariamente indisponíveis. Tente novamente mais tarde.' });
  const b = req.body || {};
  const amount = Math.round(Number(b.amount) * 100) / 100;
  const name = String(b.name || '').trim().slice(0, 100);
  const email = String(b.email || '').trim().slice(0, 150);
  const phone = String(b.phone || '').replace(/[^\d+]/g, '').slice(0, 20);
  if (!(amount >= MIN && amount <= MAX)) return res.status(400).json({ error: 'invalid_amount', message: `Informe um valor entre R$ ${MIN} e R$ ${MAX}.` });
  if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || phone.replace(/\D/g, '').length < 10 || b.terms !== true)
    return res.status(400).json({ error: 'invalid_data', message: 'Preencha nome, e-mail e telefone válidos e aceite os termos.' });
  const ref = 'vpt' + crypto.randomBytes(8).toString('hex');
  try {
    await sb('/contributions', { method: 'POST', body: JSON.stringify({ internal_reference: ref, amount }) });
    const base = process.env.PUBLIC_URL || 'https://' + req.headers.host;
    const r = await amplo('/pix/receive', { method: 'POST', body: JSON.stringify({
      identifier: ref, amount, client: { name, email, phone },
      callbackUrl: base + '/api/payment-webhook'
    }) });
    if (!r.ok || !r.data.pix || !r.data.pix.code || ['FAILED', 'REJECTED', 'CANCELED'].includes(r.data.status)) {
      await sb('/contributions?internal_reference=eq.' + ref, { method: 'PATCH', body: JSON.stringify({ payment_status: 'failed' }) });
      console.error('amplo_create_failed', r.status, r.data && r.data.errorCode);
      return res.status(502).json({ error: 'provider_error', message: 'Não foi possível gerar a cobrança. Tente novamente.' });
    }
    await sb('/contributions?internal_reference=eq.' + ref, { method: 'PATCH', body: JSON.stringify({
      provider_transaction_id: r.data.transactionId, webhook_token: r.data.webhookToken || null }) });
    // NÃO marca como pago aqui. Só o webhook/consulta confirmada faz isso.
    return res.status(200).json({ id: ref, code: r.data.pix.code, image: r.data.pix.image || null, expiresAt: r.data.pix.expiresAt || null });
  } catch (e) {
    console.error('create_payment_error', e.message);
    return res.status(500).json({ error: 'server_error', message: 'Erro ao gerar a cobrança. Tente novamente.' });
  }
};
